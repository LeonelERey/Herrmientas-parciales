#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Funciones.h"

void inicializarAutos(xAuto autos[], int tam)
{
    int i;

    for(i=0; i<tam; i++)
    {
        {
            autos[i].estado=0;
            autos[i].idCliente=-1;
        }
    }
}
void inicializarCliente(xCliente cliente[], int tam)
{
    int i;

    for(i=0; i<tam; i++)
    {
        {
            cliente[i].estado=0;
        }
    }
}
int buscarEspacio(xAuto espacio[],int tam)
{
    int lugar = -1;
    int i;
    for(i=0; i<tam; i++)
    {
        if(espacio[i].estado==0)
        {
            lugar = i;
            break;
        }
    }
    return lugar;
}
int buscarEspacioCliente(xCliente espacio[],int tam)
{
    int lugar = -1;
    int i;
    for(i=0; i<tam; i++)
    {
        if(espacio[i].estado==0)
        {
            lugar = i;
            break;
        }
    }
    return lugar;
}
void mostrarAuto(xAuto autos)
{
    printf("================================================================================\n");
    printf("\n%s\t%d\t%d\t%d\n\n", autos.patente, autos.marca, autos.idCliente,autos.horaEntrada);
}
void mostrarCliente(xCliente cliente)
{
    printf("================================================================================\n");
    printf("\n%s %s\t%s\t%d\t%d\n\n", cliente.nombre, cliente.apellido, cliente.direccion,cliente.idCliente,cliente.tarjeta);
}


void altasCliente(xCliente cliente[],int tam)
{

    int i;
    int j;
    int posicion;
    posicion=buscarEspacioCliente(cliente,tam);
    if(posicion!=-1)
    {

        for(i=0; i<tam; i++)
        {
            printf("================================================================================\n");
            printf("ingrese nombre del cliente:");
            fflush(stdin);
            gets(cliente[i].nombre);
            printf("================================================================================\n");
            printf("ingrese apellido del cliente:");
            fflush(stdin);
            gets(cliente[i].apellido);
            printf("================================================================================\n");
            printf("ingrese el id del cliente:");
            scanf("%d", &cliente[i].idCliente);
            /*for(j=0; j<tam; j++)
            {
                while(cliente[i].idCliente==cliente[j].idCliente)
                {
                    printf("================================================================================\n");
                    printf("esa id ya esta registrada\ningrese una id valida:");
                    scanf("%d",&cliente[i].idCliente);
                    printf("================================================================================\n");


                }
            }*/
            while(cliente[i].idCliente>21||cliente[i].idCliente<1)
            {
                printf("================================================================================\n");
                printf("reingrese una opcion valida entre 1 y 21:\nopcion:");
                scanf("%d",&cliente[i].idCliente);
                printf("================================================================================\n");

            }
            printf("================================================================================\n");
            printf("ingrese la direccion del cliente:");
            fflush(stdin);
            gets(cliente[i].direccion);
            printf("================================================================================\n");

            printf("ingrese el numero de tarjeta:");
            scanf("%d", &cliente[i].tarjeta);
            while(cliente[i].tarjeta<10000000||cliente[i].tarjeta>99999999)
            {
                printf("================================================================================\n");
                printf("ingrese un numero de tarjeta entre 100000000000 y 999999999999:");
                scanf("%d", &cliente[i].tarjeta);
            }


            cliente[i].estado=1;

            mostrarCliente(cliente[i]);
            break;
        }
    }
    else
    {
        printf("================================================================================\n");
        printf("No hay mas espacio disponible!\n");
    }


}
void modificar(xCliente cliente[],int tam)
{
    int i;
    int num;
    int numMod;

    printf("ingresa el numero de tarjeta q decea modificar.");
    scanf("%d", &num);
    printf("ingresa el nuevo numero.");
    scanf("%d", &numMod);

    for(i=0; i<tam; i++)
    {
        if(cliente[i].tarjeta==num)
        {
            printf("================================================================================\n");
            cliente[i].tarjeta=numMod;
            printf("se a realizado el cambio de tarjeta.\n");
            break;
        }
    }
}
void ingreso (xAuto autos[],int tam)
{
    int i;
    int posicion;

    posicion=buscarEspacio(autos,tam);
    if(posicion!=-1)
    {

        for(i=0; i<tam; i++)
        {
            printf("================================================================================\n");
            printf("ingrese la patente del vehiculo:");
            fflush(stdin);
            gets(autos[i].patente);
            printf("================================================================================\n");
            printf("ingrese la marca:\n");
            printf("================================================================================\n");

            printf("\n1- ALPHA_ROMERO\n");
            printf("2- FERRARI\n");
            printf("3- AUDI\n");
            printf("4- OTRO\n\nopcion:");

            scanf("%d",&autos[i].marca);
            while(autos[i].marca>4)
            {
                printf("================================================================================\n");
                printf("reingrese una opcion valida:\nopcion:");
                scanf("%d",&autos[i].marca);
                printf("================================================================================\n");

            }

            switch(autos[i].marca>4)
            {
            case 1:
                printf("usted eligio ALPHA_ROMERO.\n");
                break;
            case 2:
                printf("usted eligio FERRARI.\n");
                break;
            case 3:
                printf("usted eligio AUDI.\n");
                break;
            case 4:
                printf("usted eligio OTRO.\n");
                break;
            }
            printf("================================================================================\n");


            printf("================================================================================\n");
            printf("ingrese el id del cliente q usa el auto:");
            scanf("%d", &autos[i].idCliente);
            while(autos[i].idCliente>21||autos[i].idCliente<1)
            {
                printf("================================================================================\n");
                printf("reingrese una opcion valida entre 1 y 21:\nopcion:");
                scanf("%d",&autos[i].idCliente);
                printf("================================================================================\n");

            }
            printf("engrese el horario de entrada:");
            printf("================================================================================\n");
            scanf("%d", &autos[i].horaEntrada);
            if(autos[i].horaEntrada<0||autos[i].horaEntrada>24)
            {
                printf("================================================================================\n");
                printf("debe ingresar un horario entre 0 y 24 HS\n");
                scanf("%d", &autos[i].horaEntrada);
                break;
            }

            autos[i].estado=1;

            mostrarAuto(autos[i]);
            break;
        }
    }
    else
    {
        printf("================================================================================\n");
        printf("No hay mas espacio disponible!\n");
    }
}

